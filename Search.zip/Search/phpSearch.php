<style>
table, th, td {
    border: 1px solid black;
}
</style>


<?php

$search = $_POST['search'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "classDB";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "select * from students where student_id like '%$search%'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr>
    <th>Student Id</th>
    <th>Name</th>
    <th>Age</th>
    <th>Gender</th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["student_id"]. " </td>
         <td>" . $row["name"]. " </td>
          <td>" . $row["age"]. " </td>
           <td>" . $row["gender"]. " </td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "invalid application Id";
}

$conn->close();
?>